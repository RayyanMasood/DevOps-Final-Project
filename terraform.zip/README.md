# DevOps Final Project - Terraform Infrastructure

This Terraform project creates a complete AWS infrastructure for a scalable web application with auto-scaling, load balancing, databases, and monitoring.

## 🏗️ Architecture Overview

The infrastructure includes:

- **VPC** with public and private subnets across multiple AZs
- **Application Load Balancer** with HTTPS support
- **Auto Scaling Group** with 3 EC2 instances running Node.js applications
- **RDS databases** (MySQL and PostgreSQL) in private subnets
- **Security Groups** with proper access controls
- **Route53** DNS configuration (optional)
- **CloudWatch** monitoring and alarms
- **WAF** for additional security (optional)

## 📋 Prerequisites

Before you begin, ensure you have the following:

### Required Tools
- [Terraform](https://www.terraform.io/downloads.html) >= 1.0
- [AWS CLI](https://aws.amazon.com/cli/) configured with appropriate credentials
- An AWS account with appropriate permissions

### Required AWS Resources
- An AWS key pair for EC2 access
- (Optional) A registered domain name for HTTPS setup
- (Optional) An SSL certificate in AWS Certificate Manager

### AWS Permissions
Your AWS credentials should have permissions for:
- EC2 (instances, security groups, load balancers)
- RDS (database instances, subnet groups)
- VPC (networks, subnets, gateways)
- IAM (roles, policies, instance profiles)
- CloudWatch (alarms, dashboards, logs)
- S3 (for Terraform state and ALB logs)
- Route53 (if using custom domain)
- Secrets Manager (for database credentials)

## 🚀 Quick Start

### 1. Clone and Setup

```bash
# Navigate to the terraform directory
cd terraform

# Copy the example variables file
cp terraform.tfvars.example terraform.tfvars

# Edit the variables file with your specific values
vim terraform.tfvars
```

### 2. Configure Variables

Edit `terraform.tfvars` and set the required variables:

```hcl
# Required variables
project_name = "your-project-name"
environment  = "dev"  # or staging, prod
key_name     = "your-aws-key-pair"
aws_region   = "us-east-1"

# Database passwords (use environment variables for security)
# mysql_password = "set-via-env-var"
# postgres_password = "set-via-env-var"
```

### 3. Set Sensitive Variables

For security, set database passwords as environment variables:

```bash
export TF_VAR_mysql_password="YourSecurePassword123!"
export TF_VAR_postgres_password="AnotherSecurePassword456!"
```

### 4. Initialize and Deploy

```bash
# Initialize Terraform
terraform init

# Review the plan
terraform plan

# Apply the configuration
terraform apply
```

### 5. Access Your Application

After deployment, Terraform will output the application URL. Access your application via:

- **Load Balancer URL**: `http://your-alb-dns-name.amazonaws.com`
- **Custom Domain**: `https://app.yourdomain.com` (if configured)

## 📁 Project Structure

```
terraform/
├── main.tf                    # Main configuration file
├── variables.tf               # Input variable definitions
├── outputs.tf                 # Output value definitions
├── providers.tf               # Provider configurations
├── versions.tf                # Version constraints
├── terraform.tfvars.example   # Example variables file
├── README.md                  # This file
│
├── modules/
│   ├── networking/            # VPC, subnets, gateways
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── security/              # Security groups and rules
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── compute/               # Auto Scaling Group, EC2
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── user_data.sh
│   │
│   ├── database/              # RDS MySQL and PostgreSQL
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── load_balancer/         # ALB, target groups, listeners
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── route53/               # DNS records (optional)
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   └── monitoring/            # CloudWatch dashboards and alarms
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
│
└── environments/              # Environment-specific configurations
    ├── dev/
    ├── staging/
    └── prod/
```

## ⚙️ Configuration Options

### Environment-Specific Settings

#### Development
```hcl
environment = "dev"
asg_min_size = 1
asg_max_size = 3
asg_desired_capacity = 2
mysql_instance_class = "db.t3.micro"
postgres_instance_class = "db.t3.micro"
enable_nat_gateway = false
backup_retention_period = 1
```

#### Production
```hcl
environment = "prod"
asg_min_size = 3
asg_max_size = 10
asg_desired_capacity = 5
instance_type = "t3.large"
mysql_instance_class = "db.r5.large"
postgres_instance_class = "db.r5.large"
enable_nat_gateway = true
backup_retention_period = 30
```

### HTTPS Configuration

To enable HTTPS:

1. Register a domain name
2. Create an SSL certificate in AWS Certificate Manager
3. Set the variables:

```hcl
domain_name = "yourdomain.com"
subdomain = "app"
certificate_arn = "arn:aws:acm:us-east-1:123456789012:certificate/..."
```

### Monitoring Configuration

Enable monitoring and alerts:

```hcl
enable_monitoring = true
alarm_email = "admin@yourdomain.com"
high_cpu_threshold = 80
high_memory_threshold = 80
```

## 🔧 Advanced Configuration

### Backend Configuration

For production use, configure remote state storage:

```hcl
# In main.tf or backend.tf
terraform {
  backend "s3" {
    bucket         = "your-terraform-state-bucket"
    key            = "terraform.tfstate"
    region         = "us-east-1"
    encrypt        = true
    dynamodb_table = "terraform-state-lock"
  }
}
```

### Multi-Environment Setup

Create environment-specific configurations:

```bash
# Environment-specific variable files
environments/
├── dev.tfvars
├── staging.tfvars
└── prod.tfvars

# Deploy to specific environment
terraform apply -var-file="environments/prod.tfvars"
```

### Custom User Data

Modify `modules/compute/user_data.sh` to customize the application setup:

- Install additional software
- Configure monitoring agents
- Set up application-specific configurations

## 🔍 Monitoring and Logging

### CloudWatch Dashboard

After deployment, access your CloudWatch dashboard:
```
https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#dashboards:name=your-project-dev
```

### Key Metrics Monitored

- **Load Balancer**: Request count, response time, error rates
- **Auto Scaling**: Instance counts, scaling events
- **EC2**: CPU, memory, disk utilization
- **RDS**: CPU, connections, read/write IOPS
- **Application**: Custom application metrics

### Log Groups

- `/aws/ec2/var/log/messages` - System logs
- `/aws/ec2/user-data` - Instance initialization logs
- `/aws/ec2/application` - Application logs

## 🔒 Security Best Practices

### Network Security
- Private subnets for application and database tiers
- Security groups with minimal required access
- NAT gateways for outbound internet access
- Optional WAF for application-layer protection

### Data Protection
- Encrypted RDS databases with KMS
- Encrypted EBS volumes
- Secrets Manager for database credentials
- S3 bucket encryption for ALB logs

### Access Control
- IAM roles with minimal permissions
- No hardcoded credentials
- Session Manager for secure EC2 access
- Restricted SSH access via bastion host

### Monitoring
- CloudWatch alarms for security events
- VPC Flow Logs (can be enabled)
- CloudTrail for API auditing
- WAF logs for web application security

## 🛠️ Maintenance Tasks

### Regular Updates

```bash
# Update Terraform providers
terraform init -upgrade

# Plan infrastructure changes
terraform plan

# Apply updates
terraform apply
```

### Database Maintenance

- Automated backups are configured
- Maintenance windows are set for minimal impact
- Monitor RDS performance insights

### Scaling Operations

The infrastructure auto-scales based on:
- CPU utilization (target: 70%)
- Request count per instance (target: 1000/min)

Manual scaling:
```bash
# Update desired capacity
terraform apply -var="asg_desired_capacity=5"
```

## 🚨 Troubleshooting

### Common Issues

1. **Permission Denied Errors**
   - Verify AWS credentials and permissions
   - Check IAM policies

2. **Resource Limits**
   - Check AWS service quotas
   - Request limit increases if needed

3. **Health Check Failures**
   - Verify security group rules
   - Check application health endpoint
   - Review CloudWatch logs

4. **Database Connection Issues**
   - Verify security group rules
   - Check Secrets Manager access
   - Validate database credentials

### Useful Commands

```bash
# View current state
terraform show

# List all resources
terraform state list

# Get specific resource details
terraform state show aws_instance.example

# Refresh state
terraform refresh

# Import existing resources
terraform import aws_instance.example i-1234567890abcdef0
```

## 💰 Cost Optimization

### Development Environment
- Use smaller instance types (`t3.micro`, `t3.small`)
- Disable NAT gateways (use NAT instances if needed)
- Shorter backup retention periods
- Stop/start instances during off-hours

### Production Environment
- Use Reserved Instances for predictable workloads
- Enable detailed monitoring for better scaling decisions
- Use Spot Instances for non-critical workloads
- Set up cost alerts and budgets

### Estimated Monthly Costs

| Resource | Development | Production |
|----------|-------------|------------|
| EC2 Instances | $30-60 | $200-500 |
| RDS Databases | $30-50 | $200-800 |
| Load Balancer | $20 | $20 |
| NAT Gateway | $0-45 | $45-90 |
| **Total** | **$80-175** | **$465-1410** |

*Note: Costs vary by region and usage patterns*

## 🔄 Cleanup

To destroy all resources:

```bash
# Review what will be destroyed
terraform plan -destroy

# Destroy all resources
terraform destroy
```

**Warning**: This will permanently delete all resources. Ensure you have backups if needed.

## 📞 Support

For issues or questions:

1. Check the troubleshooting section above
2. Review AWS documentation for specific services
3. Check Terraform documentation for configuration syntax
4. Review CloudWatch logs for application issues

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📚 Additional Resources

- [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/)
- [Terraform Best Practices](https://www.terraform.io/docs/cloud/guides/recommended-practices/index.html)
- [AWS Security Best Practices](https://aws.amazon.com/security/security-resources/)
- [Node.js Deployment Guide](https://nodejs.org/en/docs/guides/deployment/)
